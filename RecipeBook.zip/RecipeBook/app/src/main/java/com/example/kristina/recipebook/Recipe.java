package com.example.kristina.recipebook;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.widget.ImageView;
import android.widget.TextView;


public class Recipe {
    private Activity name_of_activity;
    private ImageView image;
    private TextView ingredients;
    private TextView list_of_steps;

    public Recipe(ImageView image, String S, String S2, Activity name_of_activity){
        image = this.image;
        name_of_activity = this.name_of_activity;

        setImage(image,name_of_activity);
        setIngredients(ingredients, S);
        setStepsList(list_of_steps, S2);
    } // конструктор, який створює суцільний об'єкт , що містить image, ingredients, list_of_steps,які
      // відформатовані належним чином за допомогою методів setImage, setIngredients, setStepsList

    private void setImage(ImageView image, @NonNull Activity name_of_activity){
        name_of_activity.setContentView(image);
    } // встановлює картинку, задає її параметри

    private void setIngredients(@NonNull TextView ingredients, String S){
        ingredients.setText(S);
        ingredients.setTextSize(12);
    } // встановлює текст фідформатований необхідним чином

    private void setStepsList(@NonNull TextView list_of_steps, String S){
        list_of_steps.setText(S);
        list_of_steps.setTextSize(12);
    } // встановлює текст фідформатований необхідним чином



}
