package com.example.kristina.recipebook;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;


public class MainActivity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabHost tabHost = getTabHost();
        TabHost.TabSpec tabSpec;

        tabSpec = tabHost.newTabSpec("tag1");
        tabSpec.setIndicator("Салати");
        tabSpec.setContent(new Intent(this, TabTwo.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag2");
        tabSpec.setIndicator("Перші страви");
        tabSpec.setContent(new Intent(this, TabThree.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag3");
        tabSpec.setIndicator("Другі страви");
        tabSpec.setContent(new Intent(this, TabFour.class));
        tabHost.addTab(tabSpec);

        tabSpec = tabHost.newTabSpec("tag4");
        tabSpec.setIndicator("Десерти");
        tabSpec.setContent(new Intent(this, TabFive.class));
        tabHost.addTab(tabSpec);


        ImageView image1 = new ImageView(this);
        image1.setImageResource(R.drawable.meal);
        TextView text1 = new TextView(this);
        TextView text2 = new TextView(this);
        String S = "jfjfjfj";
        String S2 = "ddddd";
        Recipe recipe1 = new Recipe(image1, S, S2, this);

    }
}